# EPIC Checklist

- [x] Read claude.md for project guidance.
- [x] Review code quality for the targeted module(s).
- [x] Refactor the entity extraction response handling for safety and clarity.
